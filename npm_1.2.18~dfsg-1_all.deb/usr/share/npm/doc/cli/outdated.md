npm-outdated(1) -- Check for outdated packages
==============================================

## SYNOPSIS

    npm outdated [<name> [<name> ...]]

## DESCRIPTION

This command will check the registry to see if any (or, specific) installed
packages are currently outdated.

## SEE ALSO

* npm-update(1)
* npm-registry(1)
* npm-folders(1)
